//using dynamic folder page
function blogpage(props){
        return (
                <h1>dynamic folder page{props.blogid}</h1>
                
        )
}
export async function getStaticPaths() {
        return {
                //dynamic
// paths:statedata.map((ma)=>({
//         params:ma._id
// }))

                //static
            paths: [
                {  params: { blogid: '1' } },
                {  params: { blogid: '2' } },
                {  params: { blogid: '3' } },
            ],
        //     fallback: true
        fallback: false
        }
    }
    export async function getStaticProps(context) {
            const blogid= context.params.blogid;//(blogid => is a foldername)
            console.log(blogid) // its does not show in chrome console because its call ony build time (developer server side)
        return {
          props:
          {
                  blogid:blogid
          }
        }
    }
export default blogpage;