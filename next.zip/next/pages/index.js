import { Fragment } from "react";
import Link from 'next/link';
function Homepage(props){
       return( 
        <Fragment>
                <ul>
                        <li>
                                <Link href="/dynamic/new-page">
                                new one call dynamic page
                                </Link>
                        </li>
                </ul>
        <h1>{props.name}</h1>
        </Fragment>
        )
}

    

export async function getStaticProps(){
        return {
          props:{
            name:'sukki'
          }
        }
      }
export default Homepage;