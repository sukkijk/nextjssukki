import { MongoClient } from 'mongodb';

async function handler(req,res){
if(req.method === 'POST'){
        const data= req.data;
        // const {name} = data; // posting data contains name field
const client=await MongoClient.connect('mongodb+srv://sukki:bKdySp5SHHAJZzzs@cluster0.s7orh.mongodb.net/Dynamicdata?retryWrites=true&w=majority')
const db=client.db();
const fulldata=db.collection('Dynamicdata')
const result= await fulldata.insertOne(data);
console.log(result)

client.close();

res.status(200).json({message:'success'})

}
}

export default handler;