import { useRouter } from "next/router";


//use dynamic page 
const dat=
        //   {"firstName":"John", "lastName":"Doe"},
        //   {"firstName":"Anna", "lastName":"Smith"},
          {firstName:"Peter", lastName:"Jones"}
        
        
        
function Dynamicpage(){
        const router= useRouter()
        async function postdata(){
                // alert("check")
               
         const response = await fetch('/api/dynamicdata',{
                  method:'POST',
                  body: {firstName:"Peter", lastName:"Jones"},
                //   headers:{
                //           'Content-Type':'application/json',
                //           'Accept': 'application/json'
                //   }
          });
        //   console.log(response,"sjjj")
          const data = await response.json();
          console.log(data)
          router.push('/')
         }
         
        return (
        <div>
        <h1>dynamic</h1>
        <button onClick={postdata}>click</button>
        </div>
        )
}
export default Dynamicpage;